import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int sum=0,num1;
		num1=num;
		do{
		    int rem=0;
		    rem=num%10;
		    sum=sum+rem;
		    num=num/10;
		}while(num!=0);
		if(num1%sum==0)
		System.out.println("HARSHAD NUMBER");
		else
		System.out.println("NOT A HARSHAD NUMBER");
	
	}
}